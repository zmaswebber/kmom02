<h1>Page with comments</h1>

<p>This is a sample page displaying how comments can interact with a page- or froncontroller.</p>


